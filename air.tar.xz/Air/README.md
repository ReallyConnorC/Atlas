# Air AI

The voice of Air OS. A full-screen orb that listens for "Hey Air", thinks with Groq and runs your Tapo lights and plugs locally.

## Using it
- Tap the orb to talk, tap again while it's speaking to cut it off.
- Long-press the orb for the settings address and PIN.
- Orb colours: blue idle, cyan listening, violet thinking, orange speaking, red means something went wrong (it'll say what).

## Settings
Air hosts its own settings page. With your computer on the same wifi, open the address shown on the long-press card (like `http://192.168.1.40:8080`) and enter the PIN.

From there: Groq key, model, voice speed, personality, Tapo login and devices. Hit **Scan wifi** to find Tapo devices, rename them to whatever you'll say out loud.

## Tapo
Talks to devices directly on your network using Tapo's local protocol, so no cloud round trip. Uses your Tapo app email and password, stored only on the tablet. Bulbs take on/off, brightness, colour and white temperature; plugs take on/off.

Tip: give your Tapo devices fixed IPs in your router so they don't move around.

## Building
Push to GitHub and the workflow in `.github/workflows/build.yml` builds the APK and attaches it as the `Air-apk` artifact. It downloads the Vosk wake word model during the build.
