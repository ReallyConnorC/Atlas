package dev.goldenvr.air

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

// Local control for Tapo bulbs/plugs over the KLAP protocol (current firmware).
class Tapo(private val creds: () -> Pair<String, String>) {

    class Scan(val devices: List<Device>, val notes: List<String>)

    private class Session(
        val cookie: String,
        val key: ByteArray,
        val ivBase: ByteArray,
        var seq: Int,
        val sig: ByteArray,
        val expires: Long,
        val login: Int
    )

    private val bytes = "application/octet-stream".toMediaType()
    private val random = SecureRandom()
    private val sessions = ConcurrentHashMap<String, Session>()

    private val http = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .build()

    private val quick = http.newBuilder()
        .connectTimeout(700, TimeUnit.MILLISECONDS)
        .callTimeout(1500, TimeUnit.MILLISECONDS)
        .build()

    fun send(ip: String, method: String, params: JSONObject? = null): JSONObject =
        runCatching { exchange(ip, method, params) }.getOrElse { first ->
            sessions.remove(ip)
            if (first.message?.contains("login") == true) throw first
            exchange(ip, method, params)
        }

    fun info(ip: String): Device {
        val i = send(ip, "get_device_info")
        val nick = runCatching { String(Base64.decode(i.optString("nickname"), Base64.DEFAULT)) }.getOrDefault("")
        return Device(
            name = nick.ifBlank { i.optString("model", "Tapo") },
            ip = ip,
            kind = if (i.optString("type").contains("BULB", ignoreCase = true)) "bulb" else "plug",
            model = i.optString("model")
        )
    }

    suspend fun scan(): Scan = coroutineScope {
        val me = localIp() ?: throw IOException("Air isn't on wifi")
        val base = me.substringBeforeLast('.')
        val gate = Semaphore(40)

        val found = (1..254).map { "$base.$it" }
            .filter { it != me }
            .map { ip -> async(Dispatchers.IO) { gate.withPermit { if (probe(ip)) ip else null } } }
            .awaitAll()
            .filterNotNull()

        val notes = Collections.synchronizedList(mutableListOf<String>())
        val devices = found
            .map { ip ->
                async(Dispatchers.IO) {
                    runCatching { info(ip) }.getOrElse {
                        notes += "$ip: ${it.message}"
                        null
                    }
                }
            }
            .awaitAll()
            .filterNotNull()

        Scan(devices, notes.toList())
    }

    private fun probe(ip: String): Boolean = runCatching {
        val seed = ByteArray(16).also(random::nextBytes)
        val req = Request.Builder().url("http://$ip/app/handshake1").post(seed.toRequestBody(bytes)).build()
        quick.newCall(req).execute().use { it.code == 200 && it.body?.bytes()?.size == 48 }
    }.getOrDefault(false)

    private fun exchange(ip: String, method: String, params: JSONObject?): JSONObject {
        val s = session(ip)
        val payload = JSONObject()
            .put("method", method)
            .put("request_time_milis", System.currentTimeMillis())
        if (params != null) payload.put("params", params)

        val (seq, body) = synchronized(s) {
            s.seq += 1
            s.seq to seal(s, s.seq, payload.toString().toByteArray())
        }

        val (reply, _) = post("http://$ip/app/request?seq=$seq", body, s.cookie)
        val json = JSONObject(String(open(s, seq, reply)))
        val code = json.optInt("error_code", 0)
        if (code != 0) throw IOException("device said error $code")
        return json.optJSONObject("result") ?: JSONObject()
    }

    private fun session(ip: String): Session {
        val (user, pass) = creds()
        if (user.isBlank() || pass.isBlank()) throw IOException("Tapo login not set, add it in settings")
        val login = (user + "\u0000" + pass).hashCode()
        sessions[ip]?.let { if (it.login == login && it.expires > System.currentTimeMillis()) return it }

        val auth = sha256(sha1(user.toByteArray()) + sha1(pass.toByteArray()))
        val local = ByteArray(16).also(random::nextBytes)

        val (first, cookieHeader) = post("http://$ip/app/handshake1", local, null)
        if (first.size < 48) throw IOException("that's not a Tapo device")
        val remote = first.copyOfRange(0, 16)
        if (!first.copyOfRange(16, 48).contentEquals(sha256(local + remote + auth))) {
            throw IOException("Tapo login rejected, check the email and password")
        }

        val cookie = cookieHeader?.substringBefore(';') ?: throw IOException("no session cookie")
        val timeout = cookieHeader.substringAfter("TIMEOUT=", "").takeWhile { it.isDigit() }.toLongOrNull() ?: 1200
        post("http://$ip/app/handshake2", sha256(remote + local + auth), cookie)

        val seeds = local + remote + auth
        val iv = sha256("iv".toByteArray() + seeds)
        return Session(
            cookie = cookie,
            key = sha256("lsk".toByteArray() + seeds).copyOf(16),
            ivBase = iv.copyOf(12),
            seq = ByteBuffer.wrap(iv, 28, 4).int,
            sig = sha256("ldk".toByteArray() + seeds).copyOf(28),
            expires = System.currentTimeMillis() + (timeout - 60).coerceAtLeast(60) * 1000,
            login = login
        ).also { sessions[ip] = it }
    }

    private fun seal(s: Session, seq: Int, plain: ByteArray): ByteArray {
        val seqBytes = ByteBuffer.allocate(4).putInt(seq).array()
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(s.key, "AES"), IvParameterSpec(s.ivBase + seqBytes))
        val ct = c.doFinal(plain)
        return sha256(s.sig + seqBytes + ct) + ct
    }

    private fun open(s: Session, seq: Int, data: ByteArray): ByteArray {
        if (data.size <= 32) throw IOException("empty reply")
        val seqBytes = ByteBuffer.allocate(4).putInt(seq).array()
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(s.key, "AES"), IvParameterSpec(s.ivBase + seqBytes))
        return c.doFinal(data, 32, data.size - 32)
    }

    private fun post(url: String, body: ByteArray, cookie: String?): Pair<ByteArray, String?> {
        val req = Request.Builder().url(url).post(body.toRequestBody(bytes))
        if (cookie != null) req.header("Cookie", cookie)
        http.newCall(req.build()).execute().use { res ->
            if (!res.isSuccessful) throw IOException("device returned ${res.code}")
            return (res.body?.bytes() ?: ByteArray(0)) to res.header("Set-Cookie")
        }
    }

    private fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b)
    private fun sha1(b: ByteArray) = MessageDigest.getInstance("SHA-1").digest(b)
}
