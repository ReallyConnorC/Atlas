package dev.goldenvr.air

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class Brain(private val prefs: Prefs, private val home: Home) {

    private val groq = Groq { prefs.groqKey }
    private val history = mutableListOf<JSONObject>()
    private val clock = DateTimeFormatter.ofPattern("EEEE d MMMM yyyy, HH:mm")
    private val ghosts = setOf("thank you", "thanks for watching", "you", "bye")

    suspend fun transcribe(clip: ByteArray): String {
        val text = groq.transcribe(clip)
        val bare = text.lowercase().trim('.', '!', ' ')
        return if (bare.length < 2 || bare in ghosts) "" else text
    }

    suspend fun reply(input: String): String {
        history += msg("user", input)
        while (history.size > 20) history.removeAt(0)
        while (history.isNotEmpty() && history[0].optString("role") != "user") history.removeAt(0)

        val tools = if (home.devices.isNotEmpty()) TOOLS else null

        repeat(5) {
            val messages = JSONArray().put(msg("system", persona()))
            history.forEach { messages.put(it) }

            val out = groq.chat(prefs.model, messages, tools)
            val content = if (out.isNull("content")) "" else out.optString("content").trim()
            val calls = out.optJSONArray("tool_calls")

            if (calls == null || calls.length() == 0) {
                val text = content.ifEmpty { "Done." }
                history += msg("assistant", text)
                return text
            }

            history += JSONObject()
                .put("role", "assistant")
                .put("content", content)
                .put("tool_calls", calls)

            for (i in 0 until calls.length()) {
                val call = calls.getJSONObject(i)
                val fn = call.getJSONObject("function")
                val result = runCatching { tool(fn.getString("name"), args(fn.optString("arguments"))) }
                    .getOrElse { "error: ${it.message}" }
                history += JSONObject()
                    .put("role", "tool")
                    .put("tool_call_id", call.getString("id"))
                    .put("content", result)
            }
        }
        return "That took more steps than it should have. Try asking another way."
    }

    private suspend fun tool(name: String, a: JSONObject): String = when (name) {
        "list_devices" -> home.describe()
        "control_device" -> home.control(
            target = a.optString("device"),
            power = a.str("power"),
            brightness = a.num("brightness"),
            color = a.str("color"),
            kelvin = a.num("kelvin")
        )
        else -> "unknown tool $name"
    }

    private fun JSONObject.str(k: String) = if (has(k) && !isNull(k)) optString(k).takeIf { it.isNotBlank() } else null
    private fun JSONObject.num(k: String) = str(k)?.toDoubleOrNull()?.toInt()

    private fun args(raw: String): JSONObject =
        if (raw.isBlank()) JSONObject() else runCatching { JSONObject(raw) }.getOrDefault(JSONObject())

    private fun persona() = buildString {
        append("You are Air, the AI built into Air OS, living on a tablet in Connor's home. ")
        append("Everything you write is spoken aloud, so reply in one to three short sentences of plain speech: ")
        append("no markdown, lists, emoji or links. Be quick, warm and a bit dry. ")
        append("If something is unclear, ask one short question. ")
        append("It is ${LocalDateTime.now().format(clock)}. ")

        val devices = home.devices
        if (devices.isNotEmpty()) {
            append("You control these Tapo devices: ")
            append(devices.joinToString { "${it.name} (${it.kind})" })
            append(". Use control_device to change them and list_devices to check what's on. ")
            append("Plugs only switch on and off. After acting, confirm in a few words without repeating the device list.")
        } else {
            append("No smart home devices are set up yet. If asked, say they can be added from the settings page; long-press the orb to see its address.")
        }

        prefs.personality.takeIf { it.isNotBlank() }?.let {
            append(" Extra instructions from Connor: ").append(it)
        }
    }

    private fun msg(role: String, content: String) = JSONObject().put("role", role).put("content", content)

    private companion object {
        val TOOLS = JSONArray(
            """
            [
              {"type": "function", "function": {
                "name": "list_devices",
                "description": "Get the live on/off state and brightness of every Tapo light and plug.",
                "parameters": {"type": "object", "properties": {}}
              }},
              {"type": "function", "function": {
                "name": "control_device",
                "description": "Change Tapo lights and plugs. device is a device name, or 'all', 'all lights' or 'all plugs'.",
                "parameters": {"type": "object", "properties": {
                  "device": {"type": "string"},
                  "power": {"type": "string", "enum": ["on", "off", "toggle"]},
                  "brightness": {"type": "integer", "description": "1 to 100, bulbs only"},
                  "color": {"type": "string", "description": "Colour name e.g. red, blue, purple, pink, warm white, daylight"},
                  "kelvin": {"type": "integer", "description": "White temperature 2500 to 6500, bulbs only"}
                }, "required": ["device"]}
              }}
            ]
            """.trimIndent()
        )
    }
}
