package dev.goldenvr.air

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject

// Settings page served from the tablet, opened from any browser on the same wifi.
class Panel(ctx: Context, private val home: Home) : NanoHTTPD(PANEL_PORT) {

    private val prefs = Prefs(ctx)
    private val page = ctx.assets.open("panel.html").bufferedReader().use { it.readText() }

    override fun serve(session: IHTTPSession): Response = runCatching { route(session) }.getOrElse {
        reply(Response.Status.INTERNAL_ERROR, JSONObject().put("error", it.message ?: "something broke"))
    }

    private fun route(s: IHTTPSession): Response {
        val path = s.uri.trimEnd('/').ifEmpty { "/" }
        if (path == "/") return NanoHTTPD.newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", page)
        if (!path.startsWith("/api/")) return reply(Response.Status.NOT_FOUND, JSONObject().put("error", "nope"))
        if (s.headers["x-pin"] != prefs.pin) return reply(Response.Status.FORBIDDEN, JSONObject().put("error", "wrong PIN"))

        return when {
            path == "/api/config" && s.method == Method.GET -> reply(config())
            path == "/api/config" && s.method == Method.POST -> {
                save(body(s))
                reply(config())
            }
            path == "/api/scan" && s.method == Method.POST -> scan()
            path == "/api/toggle" && s.method == Method.POST -> {
                val ip = body(s).optString("ip")
                val on = runBlocking { home.toggle(ip) }
                reply(JSONObject().put("on", on))
            }
            else -> reply(Response.Status.NOT_FOUND, JSONObject().put("error", "nope"))
        }
    }

    private fun config(): JSONObject = JSONObject()
        .put("model", prefs.model)
        .put("rate", prefs.rate)
        .put("personality", prefs.personality)
        .put("keepAwake", prefs.keepAwake)
        .put("keyTail", prefs.groqKey.takeLast(4))
        .put("tapoEmail", prefs.tapoEmail)
        .put("hasTapoPass", prefs.tapoPass.isNotBlank())
        .put("devices", JSONArray(Device.dump(home.devices)))

    private fun save(b: JSONObject) {
        b.optString("groqKey").takeIf { it.isNotBlank() }?.let { prefs.groqKey = it }
        b.optString("tapoPass").takeIf { it.isNotBlank() }?.let { prefs.tapoPass = it }
        if (b.has("model")) prefs.model = b.optString("model")
        if (b.has("rate")) prefs.rate = b.optString("rate")
        if (b.has("personality")) prefs.personality = b.optString("personality")
        if (b.has("tapoEmail")) prefs.tapoEmail = b.optString("tapoEmail")
        if (b.has("keepAwake")) {
            prefs.keepAwake = b.optBoolean("keepAwake")
            Hub.keepAwake.value = prefs.keepAwake
        }
        b.optJSONArray("devices")?.let { prefs.devices = Device.dump(Device.parse(it.toString())) }
    }

    private fun scan(): Response {
        val result = runBlocking { home.tapo.scan() }
        val list = home.devices.toMutableList()
        var added = 0
        for (d in result.devices) {
            val i = list.indexOfFirst { it.ip == d.ip }
            if (i >= 0) list[i] = list[i].copy(kind = d.kind, model = d.model)
            else {
                list += d
                added++
            }
        }
        prefs.devices = Device.dump(list)
        return reply(
            config()
                .put("found", result.devices.size)
                .put("added", added)
                .put("notes", JSONArray(result.notes))
        )
    }

    private fun body(s: IHTTPSession): JSONObject {
        val files = HashMap<String, String>()
        s.parseBody(files)
        return files["postData"]?.let { runCatching { JSONObject(it) }.getOrNull() } ?: JSONObject()
    }

    private fun reply(json: JSONObject, status: Response.Status = Response.Status.OK) = reply(status, json)

    private fun reply(status: Response.Status, json: JSONObject): Response =
        NanoHTTPD.newFixedLengthResponse(status, "application/json; charset=utf-8", json.toString())
}
