package dev.goldenvr.air

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class Groq(private val key: () -> String) {

    private val json = "application/json; charset=utf-8".toMediaType()

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun transcribe(wav: ByteArray): String = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("model", "whisper-large-v3-turbo")
            .addFormDataPart("response_format", "json")
            .addFormDataPart("language", "en")
            .addFormDataPart("file", "clip.wav", wav.toRequestBody("audio/wav".toMediaType()))
            .build()
        JSONObject(post("audio/transcriptions", body)).optString("text").trim()
    }

    suspend fun chat(model: String, messages: JSONArray, tools: JSONArray?): JSONObject = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.6)
            .put("max_tokens", 1024)
        if (model.startsWith("openai/gpt-oss")) payload.put("reasoning_effort", "low")
        if (tools != null) payload.put("tools", tools).put("tool_choice", "auto")

        JSONObject(post("chat/completions", payload.toString().toRequestBody(json)))
            .getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
    }

    private fun post(path: String, body: RequestBody): String {
        val req = Request.Builder()
            .url("https://api.groq.com/openai/v1/$path")
            .header("Authorization", "Bearer ${key()}")
            .post(body)
            .build()

        http.newCall(req).execute().use { res ->
            val text = res.body?.string().orEmpty()
            if (!res.isSuccessful) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                    .getOrDefault(text.take(160))
                throw IOException("Groq ${res.code}: $msg")
            }
            return text
        }
    }
}
