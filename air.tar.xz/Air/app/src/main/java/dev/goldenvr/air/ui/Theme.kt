package dev.goldenvr.air.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import dev.goldenvr.air.Mode

val Night = Color(0xFF0B1026)
val Deep = Color(0xFF151B3A)
val Haze = Color(0xFF8C93B8)
val Star = Color(0xFFF3F1FF)
val Periwinkle = Color(0xFF7FA8FF)

private val Hurt = Color(0xFFFF4D6D) to Color(0xFFFFB3C1)

fun palette(mode: Mode, hurt: Boolean = false): Pair<Color, Color> = if (hurt) Hurt else when (mode) {
    Mode.Off -> Color(0xFF39405E) to Color(0xFF6C7396)
    Mode.Idle -> Color(0xFF4D6BFF) to Color(0xFF9FD3FF)
    Mode.Listening -> Color(0xFF2FB8FF) to Color(0xFFD6F4FF)
    Mode.Thinking -> Color(0xFF8A5CFF) to Color(0xFFFF8AD8)
    Mode.Speaking -> Color(0xFFFF9C6B) to Color(0xFFFFE3A8)
}

@Composable
fun AirTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Periwinkle,
            onPrimary = Night,
            background = Night,
            surface = Deep,
            onSurface = Star,
            onBackground = Star
        ),
        content = content
    )
}
