package dev.goldenvr.air

import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow

enum class Mode { Off, Idle, Listening, Thinking, Speaking }

sealed interface Ask {
    data object Wake : Ask
    data object Listen : Ask
}

object Hub {
    val mode = MutableStateFlow(Mode.Off)
    val level = MutableStateFlow(0f)
    val wakeReady = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val keepAwake = MutableStateFlow(true)
    val asks = Channel<Ask>(Channel.BUFFERED)
}
