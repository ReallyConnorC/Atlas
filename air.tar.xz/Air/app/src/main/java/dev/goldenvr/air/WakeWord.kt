package dev.goldenvr.air

import android.content.Context
import android.content.res.AssetManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File

class WakeWord(private val ctx: Context, private val onWake: () -> Unit) : RecognitionListener {

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var listener: SpeechService? = null
    private var held = false
    private var dead = false
    @Volatile private var armed = false

    suspend fun load() = withContext(Dispatchers.IO) {
        val dir = unpack()
        val m = Model(dir.absolutePath)
        synchronized(this@WakeWord) {
            if (dead) {
                m.close()
                return@withContext
            }
            model = m
            if (!held) open()
        }
    }

    @Synchronized fun hold() {
        held = true
        close()
    }

    @Synchronized fun release() {
        held = false
        open()
    }

    @Synchronized fun shutdown() {
        dead = true
        held = true
        close()
        model?.close()
        model = null
    }

    private fun open() {
        val m = model ?: return
        if (listener != null) return
        val rec = Recognizer(m, 16000f, PHRASES)
        recognizer = rec
        listener = SpeechService(rec, 16000f).also { it.startListening(this) }
        armed = true
    }

    private fun close() {
        armed = false
        listener?.let {
            it.stop()
            it.shutdown()
        }
        listener = null
        recognizer?.close()
        recognizer = null
    }

    override fun onPartialResult(hypothesis: String?) = scan(hypothesis, "partial")
    override fun onResult(hypothesis: String?) = scan(hypothesis, "text")
    override fun onFinalResult(hypothesis: String?) {}
    override fun onTimeout() {}
    override fun onError(exception: Exception?) {
        Hub.error.value = "Wake word: ${exception?.message ?: "mic error"}"
    }

    private fun scan(json: String?, field: String) {
        if (!armed || json == null) return
        val heard = runCatching { JSONObject(json).optString(field) }.getOrDefault("")
        if ("hey air" in heard || "okay air" in heard) {
            armed = false
            onWake()
        }
    }

    private fun unpack(): File {
        val out = File(ctx.filesDir, "vosk-model")
        val stamp = File(out, ".stamp")
        val build = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime.toString()
        if (stamp.exists() && stamp.readText() == build) return out

        out.deleteRecursively()
        if (ctx.assets.list("model").isNullOrEmpty()) error("no Vosk model in assets/model")
        copy(ctx.assets, "model", out)
        stamp.writeText(build)
        return out
    }

    private fun copy(am: AssetManager, path: String, dest: File) {
        val kids = am.list(path).orEmpty()
        if (kids.isEmpty()) {
            dest.parentFile?.mkdirs()
            am.open(path).use { input -> dest.outputStream().use { input.copyTo(it) } }
        } else {
            dest.mkdirs()
            for (kid in kids) copy(am, "$path/$kid", File(dest, kid))
        }
    }

    private companion object {
        const val PHRASES = """["hey air", "okay air", "[unk]"]"""
    }
}
