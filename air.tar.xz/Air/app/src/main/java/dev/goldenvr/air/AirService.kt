package dev.goldenvr.air

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AirService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var prefs: Prefs
    private lateinit var brain: Brain
    private lateinit var voice: Voice
    private lateinit var wake: WakeWord
    private lateinit var beeper: ToneGenerator
    private var panel: Panel? = null
    private var lock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()

        prefs = Prefs(this)
        val home = Home(prefs)
        brain = Brain(prefs, home)
        voice = Voice(this) { prefs.speechRate }
        beeper = ToneGenerator(AudioManager.STREAM_MUSIC, 55)
        wake = WakeWord(this) { Hub.asks.trySend(Ask.Wake) }
        lock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "air:ears")
            .apply { acquire() }

        panel = Panel(this, home).also { p ->
            runCatching { p.start(NanoHTTPD.SOCKET_READ_TIMEOUT, true) }
                .onFailure { Hub.error.value = "Settings page couldn't start: ${it.message}" }
        }

        Hub.mode.value = Mode.Idle

        scope.launch {
            runCatching { wake.load() }
                .onSuccess { Hub.wakeReady.value = true }
                .onFailure { Hub.error.value = "Wake word is off (${it.message}). Tap the orb to talk." }
        }
        scope.launch {
            for (ask in Hub.asks) handle()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            STOP -> stopSelf()
            HUSH -> voice.hush()
        }
        return START_NOT_STICKY
    }

    private suspend fun handle() {
        wake.hold()
        try {
            if (prefs.groqKey.isBlank()) {
                say("I need a Groq key before I can help. Long press me to see where to add it.")
                return
            }

            val heard = listen()
            if (heard.isBlank()) return

            Hub.mode.value = Mode.Thinking
            val reply = brain.reply(heard)
            say(reply)

            if (!voice.hushed && reply.trimEnd().endsWith("?")) Hub.asks.trySend(Ask.Listen)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val msg = e.message ?: e.javaClass.simpleName
            Hub.error.value = msg
            runCatching { say(sayable(msg)) }
        } finally {
            Hub.level.value = 0f
            Hub.mode.value = Mode.Idle
            wake.release()
        }
    }

    private suspend fun say(text: String) {
        Hub.mode.value = Mode.Speaking
        voice.speak(text)
    }

    private fun sayable(msg: String): String = when {
        "401" in msg || "invalid_api_key" in msg -> "My Groq key isn't working. Check it on the settings page."
        "model" in msg && ("decommission" in msg || "not exist" in msg || "not found" in msg) ->
            "That model isn't available any more. Pick another one on the settings page."
        "429" in msg -> "Groq says I'm talking too much. Give me a minute."
        "mic" in msg -> "I can't get the microphone right now."
        "Unable to resolve host" in msg || "timeout" in msg.lowercase() -> "I can't reach the internet."
        else -> "Something went wrong. ${msg.take(80)}"
    }

    private suspend fun listen(): String {
        Hub.mode.value = Mode.Listening
        beeper.startTone(ToneGenerator.TONE_PROP_BEEP, 110)
        delay(170)
        val clip = Recorder.capture { Hub.level.value = it } ?: return ""
        Hub.mode.value = Mode.Thinking
        return brain.transcribe(clip)
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Listening", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AirService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val note = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_air)
            .setContentTitle("Air is listening")
            .setContentText("Say \u201CHey Air\u201D")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setSilent(true)
            .build()

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else 0
        ServiceCompat.startForeground(this, 7, note, type)
    }

    override fun onDestroy() {
        scope.cancel()
        panel?.stop()
        wake.shutdown()
        voice.shutdown()
        beeper.release()
        lock?.let { if (it.isHeld) it.release() }
        while (Hub.asks.tryReceive().isSuccess) Unit
        Hub.mode.value = Mode.Off
        Hub.wakeReady.value = false
        Hub.level.value = 0f
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "air"
        private const val STOP = "air.stop"
        private const val HUSH = "air.hush"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AirService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, AirService::class.java).setAction(STOP))
        }

        fun hush(ctx: Context) {
            ctx.startService(Intent(ctx, AirService::class.java).setAction(HUSH))
        }

        fun send(ctx: Context, ask: Ask) {
            if (Hub.mode.value == Mode.Off) start(ctx)
            Hub.asks.trySend(ask)
        }
    }
}
