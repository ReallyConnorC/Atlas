package dev.goldenvr.air

import org.json.JSONArray
import org.json.JSONObject

data class Device(val name: String, val ip: String, val kind: String, val model: String = "") {

    val bulb get() = kind == "bulb"

    fun json(): JSONObject = JSONObject()
        .put("name", name)
        .put("ip", ip)
        .put("kind", kind)
        .put("model", model)

    companion object {
        fun parse(raw: String): List<Device> = runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Device(
                    name = o.optString("name").trim(),
                    ip = o.optString("ip").trim(),
                    kind = if (o.optString("kind") == "bulb") "bulb" else "plug",
                    model = o.optString("model")
                )
            }.filter { it.ip.isNotBlank() }
                .map { if (it.name.isBlank()) it.copy(name = "Device ${it.ip.substringAfterLast('.')}") else it }
        }.getOrDefault(emptyList())

        fun dump(list: List<Device>): String =
            JSONArray().apply { list.forEach { put(it.json()) } }.toString()
    }
}
