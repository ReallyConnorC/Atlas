package dev.goldenvr.air.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.goldenvr.air.Hub
import dev.goldenvr.air.Mode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Orb(mode: Mode, modifier: Modifier = Modifier, hurt: Boolean = false) {
    val level by Hub.level.collectAsStateWithLifecycle()

    val time by produceState(0f) {
        val start = withFrameNanos { it }
        while (true) withFrameNanos { value = (it - start) / 1_000_000_000f }
    }

    val target = when (mode) {
        Mode.Off -> 0.04f
        Mode.Idle -> 0.16f
        Mode.Listening -> 0.28f + level * 0.72f
        Mode.Thinking -> 0.42f
        Mode.Speaking -> 0.5f
    }
    val energy by animateFloatAsState(target, spring(dampingRatio = 0.55f, stiffness = 140f), label = "energy")
    val (outer, inner) = palette(mode, hurt)
    val a by animateColorAsState(outer, tween(700), label = "a")
    val b by animateColorAsState(inner, tween(700), label = "b")
    val ring by animateFloatAsState(if (mode == Mode.Thinking) 1f else 0f, tween(500), label = "ring")
    val ripple by animateFloatAsState(if (mode == Mode.Listening) 1f else 0f, tween(400), label = "ripple")
    val talk by animateFloatAsState(if (mode == Mode.Speaking) 1f else 0f, tween(400), label = "talk")

    Canvas(modifier) {
        val c = center
        val r = size.minDimension * 0.31f
        val pace = 0.6f + energy * 1.6f
        val t = time * pace

        val haloR = r * (1.9f + energy * 0.5f)
        drawCircle(
            Brush.radialGradient(listOf(a.copy(alpha = 0.08f + 0.32f * energy), Color.Transparent), c, haloR),
            haloR, c
        )

        if (ripple > 0.01f) {
            for (i in 0 until 3) {
                val p = (time * 0.55f + i / 3f) % 1f
                drawCircle(
                    color = b.copy(alpha = (1f - p) * 0.4f * ripple),
                    radius = r * (1.04f + p * (0.45f + level * 0.6f)),
                    center = c,
                    style = Stroke(1.5.dp.toPx())
                )
            }
        }

        val chatter = talk * (0.12f + 0.12f * sin(time * 11f) * sin(time * 3.7f))
        val amp = 0.014f + (energy + chatter) * 0.09f

        val body = blob(c, r, amp, t, 1f)
        drawPath(
            body,
            Brush.radialGradient(
                listOf(b, a, a.copy(alpha = 0.55f)),
                center = c + Offset(-r * 0.15f, -r * 0.2f),
                radius = r * 1.25f
            )
        )

        clipPath(body) {
            rotate(time * 18f, c) {
                drawPath(
                    blob(c, r * 0.86f, amp * 1.6f, t * 1.3f, -1f),
                    Brush.sweepGradient(listOf(a, b, a.copy(alpha = 0.2f), a), c),
                    alpha = 0.5f,
                    blendMode = BlendMode.Plus
                )
            }
            val shine = c + Offset(-r * 0.32f, -r * 0.38f)
            drawCircle(
                Brush.radialGradient(listOf(Color.White.copy(alpha = 0.5f), Color.Transparent), shine, r * 0.65f),
                r * 0.65f, shine
            )
        }

        if (ring > 0.01f) {
            val rr = r * 1.22f
            rotate(time * 240f, c) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, a, b), c),
                    startAngle = 0f,
                    sweepAngle = 300f,
                    useCenter = false,
                    topLeft = c - Offset(rr, rr),
                    size = Size(rr * 2, rr * 2),
                    alpha = ring,
                    style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
    }
}

private fun blob(c: Offset, r: Float, amp: Float, t: Float, spin: Float): Path {
    val path = Path()
    val n = 96
    for (i in 0..n) {
        val th = i * 2f * PI.toFloat() / n
        val wave = sin(3f * th + t * 1.1f * spin) * 0.5f +
            sin(5f * th - t * 1.7f) * 0.3f +
            sin(2f * th + t * 0.6f * spin) * 0.2f
        val rr = r * (1f + amp * wave)
        val x = c.x + cos(th) * rr
        val y = c.y + sin(th) * rr
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}
