package dev.goldenvr.air

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject

class Home(private val prefs: Prefs) {

    val tapo = Tapo { prefs.tapoEmail to prefs.tapoPass }

    val devices: List<Device> get() = Device.parse(prefs.devices)

    val ready get() = devices.isNotEmpty() && prefs.tapoEmail.isNotBlank()

    suspend fun describe(): String = coroutineScope {
        devices.map { d ->
            async(Dispatchers.IO) {
                runCatching { tapo.send(d.ip, "get_device_info") }.fold(
                    onSuccess = { i ->
                        buildString {
                            append(d.name).append(" | ").append(d.kind).append(" | ")
                            append(if (i.optBoolean("device_on")) "on" else "off")
                            if (d.bulb && i.optBoolean("device_on")) {
                                append(" | ").append(i.optInt("brightness")).append("% brightness")
                            }
                        }
                    },
                    onFailure = { "${d.name} | ${d.kind} | not responding" }
                )
            }
        }.awaitAll().joinToString("\n").ifEmpty { "no devices set up" }
    }

    suspend fun control(target: String, power: String?, brightness: Int?, color: String?, kelvin: Int?): String {
        val picked = pick(target)
        if (picked.isEmpty()) return "no device matches \"$target\". Known: ${devices.joinToString { it.name }}"
        return coroutineScope {
            picked.map { d ->
                async(Dispatchers.IO) {
                    runCatching { drive(d, power, brightness, color, kelvin) }
                        .getOrElse { "${d.name}: failed (${it.message})" }
                }
            }.awaitAll().joinToString("\n")
        }
    }

    suspend fun toggle(ip: String): Boolean = withContext(Dispatchers.IO) {
        val on = tapo.send(ip, "get_device_info").optBoolean("device_on")
        tapo.send(ip, "set_device_info", JSONObject().put("device_on", !on))
        !on
    }

    private fun drive(d: Device, power: String?, brightness: Int?, color: String?, kelvin: Int?): String {
        val p = JSONObject()
        when (power?.lowercase()) {
            "on" -> p.put("device_on", true)
            "off" -> p.put("device_on", false)
            "toggle" -> p.put("device_on", !tapo.send(d.ip, "get_device_info").optBoolean("device_on"))
        }
        if (d.bulb && p.optBoolean("device_on", true)) {
            brightness?.let { p.put("brightness", it.coerceIn(1, 100)) }
            if (!color.isNullOrBlank() && !paint(p, color)) return "${d.name}: unknown colour \"$color\""
            kelvin?.let { p.put("color_temp", it.coerceIn(2500, 6500)) }
            if (!p.has("device_on") && p.length() > 0) p.put("device_on", true)
        }
        if (p.length() == 0) return "${d.name}: nothing to change (plugs only do on/off)"
        tapo.send(d.ip, "set_device_info", p)
        return "${d.name}: ok"
    }

    private fun pick(target: String): List<Device> {
        val all = devices
        val t = target.lowercase().trim()
        val lights = listOf("light", "bulb", "lamp")

        if (t.isBlank() || t == "all" || t == "everything" || t == "all devices") return all
        if (t.startsWith("all ") || t.startsWith("every ")) {
            return when {
                lights.any { it in t } -> all.filter { it.bulb }
                "plug" in t || "socket" in t -> all.filter { !it.bulb }
                else -> all
            }
        }

        all.filter { it.name.equals(t, ignoreCase = true) }.ifEmpty { null }?.let { return it }
        all.filter { it.name.lowercase() in t || t in it.name.lowercase() }.ifEmpty { null }?.let { return it }
        val words = t.split(' ', '-', '_').filter { it.length > 2 && it !in setOf("the", "light", "lights") }
        return all.filter { d -> words.any { it in d.name.lowercase() } }
    }

    private fun paint(p: JSONObject, name: String): Boolean {
        val n = name.lowercase().replace("colour", "").replace("color", "").trim()
        WHITES[n]?.let {
            p.put("color_temp", it)
            return true
        }
        HUES[n]?.let { (h, s) ->
            p.put("hue", h).put("saturation", s).put("color_temp", 0)
            return true
        }
        return false
    }

    private companion object {
        val WHITES = mapOf(
            "white" to 4000, "warm white" to 2700, "warm" to 2700, "soft white" to 3000,
            "cool white" to 5500, "cool" to 5500, "daylight" to 6500, "cold white" to 6500
        )
        val HUES = mapOf(
            "red" to (0 to 100), "orange" to (25 to 100), "amber" to (35 to 100),
            "yellow" to (55 to 100), "lime" to (90 to 100), "green" to (120 to 100),
            "teal" to (170 to 100), "cyan" to (185 to 100), "aqua" to (185 to 80),
            "sky blue" to (200 to 70), "light blue" to (210 to 50), "blue" to (240 to 100),
            "indigo" to (260 to 100), "purple" to (280 to 100), "violet" to (275 to 90),
            "magenta" to (300 to 100), "pink" to (330 to 60), "hot pink" to (320 to 90),
            "rose" to (345 to 70)
        )
    }
}
