package dev.goldenvr.air

import android.content.Context
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("air", Context.MODE_PRIVATE)

    var groqKey by text("groq_key")
    var model by text("model", "openai/gpt-oss-120b")
    var rate by text("rate", "1.0")
    var personality by text("personality")
    var tapoEmail by text("tapo_email")
    var tapoPass by text("tapo_pass")
    var devices by text("devices", "[]")

    var keepAwake: Boolean
        get() = sp.getBoolean("keep_awake", true)
        set(v) = sp.edit().putBoolean("keep_awake", v).apply()

    val pin: String
        get() = sp.getString("pin", null) ?: (1000..9999).random().toString().also {
            sp.edit().putString("pin", it).apply()
        }

    val speechRate: Float get() = rate.toFloatOrNull()?.coerceIn(0.5f, 2f) ?: 1f

    private fun text(key: String, fallback: String = "") = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String =
            sp.getString(key, null)?.takeIf { it.isNotBlank() } ?: fallback

        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            sp.edit().putString(key, value.trim()).apply()
        }
    }
}
