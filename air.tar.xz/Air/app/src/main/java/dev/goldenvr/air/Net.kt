package dev.goldenvr.air

import java.net.Inet4Address
import java.net.NetworkInterface

fun localIp(): String? = runCatching {
    NetworkInterface.getNetworkInterfaces().toList()
        .filter { it.isUp && !it.isLoopback && !it.isVirtual }
        .sortedByDescending { it.name.startsWith("wlan") }
        .flatMap { it.inetAddresses.toList() }
        .filterIsInstance<Inet4Address>()
        .firstOrNull { it.isSiteLocalAddress }
        ?.hostAddress
}.getOrNull()

const val PANEL_PORT = 8080

fun panelAddress(): String? = localIp()?.let { "http://$it:$PANEL_PORT" }
