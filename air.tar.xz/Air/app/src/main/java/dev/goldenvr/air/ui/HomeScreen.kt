package dev.goldenvr.air.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.goldenvr.air.AirService
import dev.goldenvr.air.Ask
import dev.goldenvr.air.Hub
import dev.goldenvr.air.Mode
import dev.goldenvr.air.Prefs
import dev.goldenvr.air.panelAddress
import kotlinx.coroutines.delay

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val mode by Hub.mode.collectAsStateWithLifecycle()
    val error by Hub.error.collectAsStateWithLifecycle()
    val keepAwake by Hub.keepAwake.collectAsStateWithLifecycle()

    var card by remember { mutableStateOf(false) }
    var lastError by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val asker = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { got ->
        if (got[Manifest.permission.RECORD_AUDIO] == true) pending?.invoke()
        else Hub.error.value = "Air can't hear you without mic access"
        pending = null
    }

    fun withMic(action: () -> Unit) {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) return action()
        pending = action
        val wanted = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        asker.launch(wanted.toTypedArray())
    }

    LaunchedEffect(Unit) {
        val prefs = Prefs(ctx)
        Hub.keepAwake.value = prefs.keepAwake
        if (prefs.groqKey.isBlank()) card = true
        withMic { if (Hub.mode.value == Mode.Off) AirService.start(ctx) }
    }

    DisposableEffect(keepAwake) {
        view.keepScreenOn = keepAwake
        onDispose { view.keepScreenOn = false }
    }

    LaunchedEffect(error) {
        val e = error ?: return@LaunchedEffect
        lastError = e
        delay(4500)
        Hub.error.value = null
    }

    val glowTarget = palette(mode, error != null).first
    val glow by animateColorAsState(glowTarget, tween(900), label = "glow")

    Box(
        Modifier
            .fillMaxSize()
            .background(Night)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(glow.copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(size.width / 2f, size.height / 2f),
                        radius = size.maxDimension * 0.6f
                    )
                )
            }
    ) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val orbSize = minOf(maxWidth, maxHeight) * 0.82f
            Orb(
                mode = mode,
                hurt = error != null,
                modifier = Modifier
                    .size(orbSize)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = {
                                when (Hub.mode.value) {
                                    Mode.Off -> withMic { AirService.send(ctx, Ask.Listen) }
                                    Mode.Idle -> AirService.send(ctx, Ask.Listen)
                                    Mode.Speaking -> AirService.hush(ctx)
                                    else -> Unit
                                }
                            },
                            onLongPress = { card = true }
                        )
                    }
            )
        }

        AnimatedVisibility(
            visible = card,
            enter = fadeIn(tween(220)) + scaleIn(tween(260), initialScale = 0.94f),
            exit = fadeOut(tween(180)) + scaleOut(tween(180), targetScale = 0.96f)
        ) {
            InfoCard(
                running = mode != Mode.Off,
                lastError = lastError,
                onClose = { card = false },
                onPower = {
                    if (mode == Mode.Off) withMic { AirService.start(ctx) } else AirService.stop(ctx)
                }
            )
        }
    }
}

@Composable
private fun InfoCard(running: Boolean, lastError: String?, onClose: () -> Unit, onPower: () -> Unit) {
    val ctx = LocalContext.current
    val address = remember { panelAddress() }
    val pin = remember { Prefs(ctx).pin }
    val wakeReady by Hub.wakeReady.collectAsStateWithLifecycle()
    val quiet = remember { MutableInteractionSource() }

    Box(
        Modifier
            .fillMaxSize()
            .background(Night.copy(alpha = 0.72f))
            .clickable(interactionSource = quiet, indication = null, onClick = onClose),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .padding(24.dp)
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(Deep)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Air settings", color = Star, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text("On your computer, open", color = Haze, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                address ?: "Connect the tablet to wifi first",
                color = Periwinkle,
                fontSize = 22.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text("PIN", color = Haze, fontSize = 13.sp)
            Text(pin, color = Star, fontSize = 30.sp, letterSpacing = 8.sp, fontFamily = FontFamily.Monospace)

            Spacer(Modifier.height(10.dp))
            Status(
                if (!running) "Air is stopped" else if (wakeReady) "Listening for \u201CHey Air\u201D" else "Wake word off, tap the orb to talk",
                ok = running && wakeReady
            )
            if (lastError != null) {
                Text(lastError, color = Color(0xFFFFB3C1), fontSize = 12.sp, textAlign = TextAlign.Center)
            }

            Spacer(Modifier.height(10.dp))
            Text(
                if (running) "Stop Air" else "Start Air",
                color = Night,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (running) Haze else Periwinkle)
                    .clickable(onClick = onPower)
                    .padding(horizontal = 26.dp, vertical = 12.dp)
            )
        }
    }
}

@Composable
private fun Status(text: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (ok) Color(0xFF6CF2B0) else Haze)
        )
        Spacer(Modifier.size(8.dp))
        Text(text, color = Haze, fontSize = 13.sp)
    }
}
