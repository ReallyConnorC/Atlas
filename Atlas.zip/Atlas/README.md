# Atlas

Private voice assistant for Android. Wake word runs fully offline (Vosk), speech-to-text and the brain run on Groq, and it can drive Home Assistant if you hook it up.

Say "Hey Atlas" (or "Okay Atlas"), or tap the orb.

## Setup

1. Download `vosk-model-small-en-us-0.15.zip` from https://alphacephei.com/vosk/models
2. Unzip it and copy the *contents* (the `am`, `conf`, `graph`, `ivector` folders etc.) into `app/src/main/assets/model/`
3. Open the project in Android Studio, let Gradle sync, then Build > Build APK(s)
4. Install, open, paste your Groq key from https://console.groq.com/keys into settings

Without the Vosk model the app still works, just tap-to-talk only.

## Home Assistant

In HA: your profile > Security > Long-lived access tokens > create one. Put the server address (eg `http://192.168.1.20:8123`) and the token into Atlas settings. Then try "turn the living room lights off" or "set the bedroom to 30 percent".

## Notes

- Model defaults to `llama-3.3-70b-versatile`. Swap it in settings for anything on Groq that supports tool calls. Check the console for what's current.
- Speech-to-text uses `whisper-large-v3-turbo` on Groq.
- Voice output is the phone's built-in TTS. Install Google's speech engine and pick a nicer voice in Android settings > Text-to-speech for a big upgrade.
- On Samsung / Xiaomi / OnePlus, turn off battery optimisation for Atlas or the background listening gets killed.
- If the reply ends in a question, Atlas keeps listening for your answer without needing the wake word again.
