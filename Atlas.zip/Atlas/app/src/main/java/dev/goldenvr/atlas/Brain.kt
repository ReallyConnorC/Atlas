package dev.goldenvr.atlas

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class Brain(private val prefs: Prefs) {

    private val groq = Groq { prefs.groqKey }
    private val home = HomeAssistant(prefs)
    private val history = mutableListOf<JSONObject>()
    private val clock = DateTimeFormatter.ofPattern("EEEE d MMMM yyyy, HH:mm")
    private val ghosts = setOf("thank you", "thanks for watching", "you", "bye")

    suspend fun transcribe(clip: ByteArray): String {
        if (prefs.groqKey.isBlank()) throw IOException("Add your Groq key in settings")
        val text = groq.transcribe(clip)
        val bare = text.lowercase().trim('.', '!', ' ')
        return if (bare.length < 2 || bare in ghosts) "" else text
    }

    suspend fun reply(input: String): String {
        if (prefs.groqKey.isBlank()) return "I need a Groq API key before I can think. Drop one in settings."

        history += msg("user", input)
        while (history.size > 20) history.removeAt(0)
        while (history.isNotEmpty() && history[0].optString("role") != "user") history.removeAt(0)

        val tools = if (home.ready) TOOLS else null

        repeat(5) {
            val messages = JSONArray().put(msg("system", persona()))
            history.forEach { messages.put(it) }

            val out = groq.chat(prefs.model, messages, tools)
            val content = if (out.isNull("content")) "" else out.optString("content").trim()
            val calls = out.optJSONArray("tool_calls")

            if (calls == null || calls.length() == 0) {
                val text = content.ifEmpty { "Done." }
                history += msg("assistant", text)
                return text
            }

            history += JSONObject()
                .put("role", "assistant")
                .put("content", content)
                .put("tool_calls", calls)

            for (i in 0 until calls.length()) {
                val call = calls.getJSONObject(i)
                val fn = call.getJSONObject("function")
                val result = runCatching { tool(fn.getString("name"), parseArgs(fn.optString("arguments"))) }
                    .getOrElse { "error: ${it.message}" }
                history += JSONObject()
                    .put("role", "tool")
                    .put("tool_call_id", call.getString("id"))
                    .put("content", result)
            }
        }
        return "That took more steps than it should have. Try asking another way."
    }

    private suspend fun tool(name: String, args: JSONObject): String = withContext(Dispatchers.IO) {
        when (name) {
            "get_entities" -> home.entities(args.optString("domain").takeIf { it.isNotBlank() })
            "call_service" -> {
                val data = args.optJSONObject("data")
                    ?: args.optString("data").takeIf { it.startsWith("{") }?.let { JSONObject(it) }
                home.call(
                    args.getString("domain"),
                    args.getString("service"),
                    args.getString("entity_id"),
                    data
                )
            }
            else -> "unknown tool $name"
        }
    }

    private fun parseArgs(raw: String): JSONObject =
        if (raw.isBlank()) JSONObject() else runCatching { JSONObject(raw) }.getOrDefault(JSONObject())

    private fun persona() = buildString {
        append("You are Atlas, a voice assistant that lives on a phone at home. ")
        append("Everything you write is read aloud, so answer in one to three short sentences, ")
        append("plain speech only: no markdown, lists, emoji or URLs. Be warm, quick and a little dry. ")
        append("If you need more info, ask one short question. ")
        append("It is ${LocalDateTime.now().format(clock)}. ")
        if (home.ready) {
            append("You can control the smart home through Home Assistant. ")
            append("Use get_entities to find the right entity_id before calling a service unless you already know it. ")
            append("After acting, confirm in a few words.")
        } else {
            append("Smart home control isn't set up yet; if asked, say it can be linked in settings.")
        }
    }

    private fun msg(role: String, content: String) = JSONObject().put("role", role).put("content", content)

    private companion object {
        val TOOLS = JSONArray(
            """
            [
              {"type": "function", "function": {
                "name": "get_entities",
                "description": "List smart home devices and their current state. Pass a domain like light, switch, climate, media_player, cover, fan, lock or sensor to narrow it down.",
                "parameters": {"type": "object", "properties": {
                  "domain": {"type": "string", "description": "Optional entity domain"}
                }}
              }},
              {"type": "function", "function": {
                "name": "call_service",
                "description": "Control a device through Home Assistant, e.g. light.turn_on, light.turn_off, switch.toggle, climate.set_temperature, media_player.media_pause.",
                "parameters": {"type": "object", "properties": {
                  "domain": {"type": "string"},
                  "service": {"type": "string"},
                  "entity_id": {"type": "string"},
                  "data": {"type": "object", "description": "Extra service data such as brightness_pct, color_name or temperature"}
                }, "required": ["domain", "service", "entity_id"]}
              }}
            ]
            """.trimIndent()
        )
    }
}
