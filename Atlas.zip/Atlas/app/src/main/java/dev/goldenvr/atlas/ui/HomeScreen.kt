package dev.goldenvr.atlas.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.goldenvr.atlas.Ask
import dev.goldenvr.atlas.AtlasService
import dev.goldenvr.atlas.Hub
import dev.goldenvr.atlas.Line
import dev.goldenvr.atlas.Mode
import dev.goldenvr.atlas.Prefs
import kotlinx.coroutines.delay

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val mode by Hub.mode.collectAsStateWithLifecycle()
    val lines by Hub.lines.collectAsStateWithLifecycle()
    val wakeReady by Hub.wakeReady.collectAsStateWithLifecycle()
    val error by Hub.error.collectAsStateWithLifecycle()

    var settings by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    var lastError by remember { mutableStateOf("") }

    val asker = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { got ->
        if (got[Manifest.permission.RECORD_AUDIO] == true) pending?.invoke()
        else Hub.error.value = "Atlas can't hear you without mic access"
        pending = null
    }

    fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

    fun withMic(action: () -> Unit) {
        if (hasMic()) return action()
        pending = action
        val wanted = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        asker.launch(wanted.toTypedArray())
    }

    LaunchedEffect(Unit) {
        if (Prefs(ctx).groqKey.isBlank()) settings = true
        else if (hasMic() && Hub.mode.value == Mode.Off) AtlasService.start(ctx)
    }

    LaunchedEffect(error) {
        val e = error ?: return@LaunchedEffect
        lastError = e
        delay(4500)
        Hub.error.value = null
    }

    val (glowColor, _) = palette(mode)
    val glow by animateColorAsState(glowColor, tween(900), label = "glow")

    Box(
        Modifier
            .fillMaxSize()
            .background(Night)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(glow.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(size.width / 2f, size.height * 0.36f),
                        radius = size.maxDimension * 0.6f
                    )
                )
            }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding()
        ) {
            TopRow(
                on = mode != Mode.Off,
                onPower = {
                    if (mode == Mode.Off) withMic { AtlasService.start(ctx) } else AtlasService.stop(ctx)
                },
                onSettings = { settings = true }
            )

            BoxWithConstraints(
                Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                val orbSize = minOf(maxWidth * 0.72f, maxHeight * 0.68f)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Orb(
                        mode = mode,
                        modifier = Modifier
                            .size(orbSize)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                when (mode) {
                                    Mode.Off -> withMic { AtlasService.send(ctx, Ask.Listen) }
                                    Mode.Idle -> AtlasService.send(ctx, Ask.Listen)
                                    Mode.Speaking -> AtlasService.hush(ctx)
                                    else -> Unit
                                }
                            }
                    )
                    AnimatedContent(
                        targetState = status(mode, wakeReady),
                        transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(200)) },
                        label = "status"
                    ) { text ->
                        Text(text, color = Haze, fontSize = 15.sp, letterSpacing = 0.3.sp)
                    }
                }
            }

            Transcript(
                lines,
                Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            )

            InputBar { text -> withMic { AtlasService.send(ctx, Ask.Typed(text)) } }
        }

        AnimatedVisibility(
            visible = error != null,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 64.dp, start = 24.dp, end = 24.dp)
        ) {
            Text(
                lastError,
                color = Star,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF3A1E3A))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }

    if (settings) SettingsSheet(onDismiss = { settings = false })
}

private fun status(mode: Mode, wakeReady: Boolean) = when (mode) {
    Mode.Off -> "Tap to wake me up"
    Mode.Idle -> if (wakeReady) "Say \u201CHey Atlas\u201D or tap" else "Tap to talk"
    Mode.Listening -> "Listening"
    Mode.Thinking -> "Thinking"
    Mode.Speaking -> "Tap to cut me off"
}

@Composable
private fun TopRow(on: Boolean, onPower: () -> Unit, onSettings: () -> Unit) {
    val dot by animateColorAsState(if (on) Color(0xFF6CF2B0) else Haze.copy(alpha = 0.5f), label = "dot")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 24.dp, end = 12.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Atlas", color = Star, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        Row(
            Modifier
                .clip(CircleShape)
                .background(Deep)
                .clickable(onClick = onPower)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dot)
            )
            Spacer(Modifier.width(8.dp))
            Text(if (on) "On" else "Off", color = Star, fontSize = 13.sp)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = Haze)
        }
    }
}

@Composable
private fun Transcript(lines: List<Line>, modifier: Modifier) {
    val list = rememberLazyListState()
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) list.animateScrollToItem(lines.lastIndex)
    }

    if (lines.isEmpty()) {
        Box(modifier.padding(horizontal = 40.dp), contentAlignment = Alignment.Center) {
            Text(
                "Ask anything, or tell me to dim the lights.",
                color = Haze.copy(alpha = 0.7f),
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
        }
        return
    }

    LazyColumn(
        state = list,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier
            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.verticalGradient(0f to Color.Transparent, 0.3f to Color.Black),
                    blendMode = BlendMode.DstIn
                )
            }
    ) {
        items(lines, key = { it.id }) { line ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .animateItem(),
                horizontalArrangement = if (line.mine) Arrangement.End else Arrangement.Start
            ) {
                if (line.mine) {
                    Text(
                        line.text,
                        color = Star.copy(alpha = 0.85f),
                        fontSize = 14.sp,
                        modifier = Modifier
                            .widthIn(max = 280.dp)
                            .clip(RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp))
                            .background(Deep)
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                } else {
                    Text(
                        line.text,
                        color = Star,
                        fontSize = 16.sp,
                        lineHeight = 22.sp,
                        modifier = Modifier.widthIn(max = 320.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun InputBar(onSend: (String) -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    val submit = {
        if (text.isNotBlank()) {
            onSend(text.trim())
            text = ""
        }
    }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Deep)
            .padding(start = 20.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            textStyle = TextStyle(color = Star, fontSize = 15.sp),
            cursorBrush = SolidColor(Periwinkle),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { submit() }),
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 16.dp),
            decorationBox = { field ->
                Box {
                    if (text.isEmpty()) Text("Type instead", color = Haze.copy(alpha = 0.6f), fontSize = 15.sp)
                    field()
                }
            }
        )
        IconButton(onClick = submit, enabled = text.isNotBlank()) {
            Icon(
                Icons.AutoMirrored.Rounded.Send,
                contentDescription = "Send",
                tint = if (text.isNotBlank()) Periwinkle else Haze.copy(alpha = 0.4f)
            )
        }
    }
}
