package dev.goldenvr.atlas

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class HomeAssistant(private val prefs: Prefs) {

    private val http = OkHttpClient.Builder()
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    private val noisy = setOf(
        "sensor", "binary_sensor", "update", "automation", "script", "zone", "person", "sun",
        "device_tracker", "button", "number", "select", "event", "image", "tts", "conversation"
    )

    val ready get() = prefs.haUrl.isNotBlank() && prefs.haToken.isNotBlank()

    private val base get() = prefs.haUrl.trim().trimEnd('/')

    fun entities(domain: String?): String {
        val all = JSONArray(send(Request.Builder().url("$base/api/states").get()))
        val out = StringBuilder()
        var count = 0
        for (i in 0 until all.length()) {
            val e = all.getJSONObject(i)
            val id = e.getString("entity_id")
            val kind = id.substringBefore('.')
            if (domain.isNullOrBlank()) {
                if (kind in noisy) continue
            } else if (kind != domain) continue

            val name = e.optJSONObject("attributes")?.optString("friendly_name").orEmpty()
            out.append(id).append(" | ").append(name).append(" | ").append(e.optString("state")).append('\n')
            if (++count >= 80) break
        }
        return out.toString().ifEmpty { "nothing found" }
    }

    fun call(domain: String, service: String, entityId: String, data: JSONObject?): String {
        val body = (data ?: JSONObject()).put("entity_id", entityId)
        send(Request.Builder().url("$base/api/services/$domain/$service").post(body.toString().toRequestBody(JSON_TYPE)))
        return "ok"
    }

    private fun send(builder: Request.Builder): String {
        val req = builder.header("Authorization", "Bearer ${prefs.haToken.trim()}").build()
        http.newCall(req).execute().use { res ->
            val text = res.body?.string().orEmpty()
            if (!res.isSuccessful) throw IOException("Home Assistant ${res.code}")
            return text
        }
    }
}
