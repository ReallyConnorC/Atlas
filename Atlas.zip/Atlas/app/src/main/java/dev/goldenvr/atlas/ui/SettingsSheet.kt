package dev.goldenvr.atlas.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.goldenvr.atlas.Prefs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var key by remember { mutableStateOf(prefs.groqKey) }
    var model by remember { mutableStateOf(prefs.model) }
    var haUrl by remember { mutableStateOf(prefs.haUrl) }
    var haToken by remember { mutableStateOf(prefs.haToken) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Deep
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .padding(bottom = 36.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Settings", color = Star, fontSize = 22.sp, fontWeight = FontWeight.Medium)

            Field("Groq API key", key, secret = true) { key = it }
            Field("Model", model) { model = it }

            Spacer(Modifier.height(4.dp))
            Text("Home Assistant", color = Star, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(
                "Optional. Lets Atlas see and control your lights, plugs and the rest.",
                color = Haze,
                fontSize = 13.sp
            )
            Field("Server address", haUrl, hint = "http://homeassistant.local:8123", type = KeyboardType.Uri) { haUrl = it }
            Field("Long-lived access token", haToken, secret = true) { haToken = it }

            Button(
                onClick = {
                    prefs.groqKey = key
                    prefs.model = model
                    prefs.haUrl = haUrl
                    prefs.haToken = haToken
                    onDismiss()
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Periwinkle, contentColor = Night),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .height(52.dp)
            ) {
                Text("Save", fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    secret: Boolean = false,
    hint: String? = null,
    type: KeyboardType = KeyboardType.Text,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        placeholder = { if (hint != null) Text(hint, color = Haze.copy(alpha = 0.5f)) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else type),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Periwinkle,
            unfocusedBorderColor = Haze.copy(alpha = 0.3f),
            focusedLabelColor = Periwinkle,
            unfocusedLabelColor = Haze,
            focusedTextColor = Star,
            unfocusedTextColor = Star,
            cursorColor = Periwinkle
        ),
        modifier = Modifier.fillMaxWidth()
    )
}
