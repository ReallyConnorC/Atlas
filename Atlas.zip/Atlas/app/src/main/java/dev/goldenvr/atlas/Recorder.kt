package dev.goldenvr.atlas

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

object Recorder {
    private const val RATE = 16_000
    private const val FRAME_MS = 50

    @SuppressLint("MissingPermission")
    suspend fun capture(onLevel: (Float) -> Unit): ByteArray? = withContext(Dispatchers.IO) {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(min, RATE * 2)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            error("mic is busy")
        }

        val frame = ShortArray(RATE * FRAME_MS / 1000)
        val pcm = ByteArrayOutputStream()
        var floor = 300.0
        var heard = false
        var quiet = 0
        var elapsed = 0

        rec.startRecording()
        try {
            while (isActive) {
                val n = rec.read(frame, 0, frame.size)
                if (n < 0) break
                if (n == 0) continue

                var sum = 0.0
                for (i in 0 until n) {
                    val s = frame[i].toInt()
                    sum += (s * s).toDouble()
                    pcm.write(s and 0xFF)
                    pcm.write((s shr 8) and 0xFF)
                }
                val rms = sqrt(sum / n)
                onLevel((rms / 4000.0).coerceIn(0.0, 1.0).toFloat())
                elapsed += FRAME_MS

                if (rms > maxOf(450.0, floor * 2.8)) {
                    heard = true
                    quiet = 0
                } else {
                    quiet += FRAME_MS
                    floor = floor * 0.95 + rms * 0.05
                }

                if (heard && quiet >= 900) break
                if (!heard && elapsed >= 6000) break
                if (elapsed >= 20_000) break
            }
        } finally {
            rec.stop()
            rec.release()
            onLevel(0f)
        }

        if (heard) wav(pcm.toByteArray()) else null
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val head = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt(36 + pcm.size)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16)
            putShort(1.toShort())
            putShort(1.toShort())
            putInt(RATE)
            putInt(RATE * 2)
            putShort(2.toShort())
            putShort(16.toShort())
            put("data".toByteArray())
            putInt(pcm.size)
        }.array()
        return head + pcm
    }
}
