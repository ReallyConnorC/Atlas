package dev.goldenvr.atlas

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

class Voice(ctx: Context) {

    private val ready = CompletableDeferred<Boolean>()
    private val tts = TextToSpeech(ctx.applicationContext) { ready.complete(it == TextToSpeech.SUCCESS) }

    @Volatile var hushed = false
        private set

    suspend fun speak(text: String) {
        if (!ready.await()) return
        hushed = false
        tts.setSpeechRate(1.05f)

        suspendCancellableCoroutine<Unit> { cont ->
            val once = AtomicBoolean(false)
            fun finish() {
                if (once.compareAndSet(false, true)) cont.resume(Unit)
            }

            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) = finish()
                override fun onStop(utteranceId: String?, interrupted: Boolean) = finish()
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) = finish()
            })
            cont.invokeOnCancellation { tts.stop() }
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "atlas-${System.nanoTime()}")
        }
    }

    fun hush() {
        hushed = true
        tts.stop()
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
