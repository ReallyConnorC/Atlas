package dev.goldenvr.atlas

import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

enum class Mode { Off, Idle, Listening, Thinking, Speaking }

data class Line(val mine: Boolean, val text: String, val id: Long = System.nanoTime())

sealed interface Ask {
    data object Wake : Ask
    data object Listen : Ask
    data class Typed(val text: String) : Ask
}

object Hub {
    val mode = MutableStateFlow(Mode.Off)
    val level = MutableStateFlow(0f)
    val wakeReady = MutableStateFlow(false)
    val lines = MutableStateFlow<List<Line>>(emptyList())
    val error = MutableStateFlow<String?>(null)
    val asks = Channel<Ask>(Channel.BUFFERED)

    fun post(line: Line) = lines.update { (it + line).takeLast(50) }
}
