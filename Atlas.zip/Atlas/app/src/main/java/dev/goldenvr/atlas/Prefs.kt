package dev.goldenvr.atlas

import android.content.Context
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("atlas", Context.MODE_PRIVATE)

    var groqKey by text("groq_key")
    var model by text("model", "llama-3.3-70b-versatile")
    var haUrl by text("ha_url")
    var haToken by text("ha_token")

    private fun text(key: String, fallback: String = "") = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String =
            sp.getString(key, null)?.takeIf { it.isNotBlank() } ?: fallback

        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            sp.edit().putString(key, value.trim()).apply()
        }
    }
}
